# run status

This run of all records completed only through the planning step

```
time (conda run -n orchestrator --no-capture-output python3 scripts/run_pipeline.py \
  --log-level DEBUG --set workers=40 --set records=dataset/v2/combined.jsonl)
```

last output
```
2026-09-18 03:54:27,334 - __main__ - INFO - Saved 167642 plans to data/intermediate/plan_outputs.jsonl

============================================================
PLAN SUMMARY
============================================================
Total records planned: 167642
Records with no mappings: 56132 (33.5%)
Records with flags: 61651 (36.8%)

Mappings by ontology:
  ENVO: 22578
  MONDO: 61912
  UBERON: 89686
============================================================
```

